import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, TextInput } from 'react-native';
import client from '../api/client';
import StatusBadge from '../components/StatusBadge';
import OfflineManager from '../services/OfflineManager';
import NetInfo from '@react-native-community/netinfo';

const ProductDetailsScreen = ({ route, navigation }) => {
  // Safe destructuring in case params are missing
  const { product: initialProduct } = route.params || {};

  const [product, setProduct] = useState(initialProduct || {
    id: 0, name: 'Loading...', sku: '...', quantity: 0, min_stock_level: 0
  });
  const [adjustAmount, setAdjustAmount] = useState('1');
  const [isConnected, setIsConnected] = useState(true);

  useEffect(() => {
    if (!initialProduct) {
      navigation.goBack(); // Safety check: Go back if no product data
    }
    const unsubscribe = NetInfo.addEventListener(state => setIsConnected(state.isConnected));
    return unsubscribe;
  }, []);

  const updateStock = async (action) => {
    // 1. Validate the number
    const amount = parseInt(adjustAmount);
    if (!amount || isNaN(amount)) {
      Alert.alert("Error", "Please enter a valid number");
      return;
    }

    // 2. Calculate the New Total manually
    const newQty = action === 'add' ? product.quantity + amount : product.quantity - amount;

    if (newQty < 0) {
      Alert.alert("Error", "Stock cannot be negative");
      return;
    }

    // 3. Handle Offline Mode
    if (!isConnected) {
      const saved = await OfflineManager.addToQueue('UPDATE_STOCK', { id: product.id, quantity: newQty });
      if (saved) {
        setProduct({ ...product, quantity: newQty });
        Alert.alert("Saved Offline", "Stock update queued.");
      }
      return;
    }

    // 4. Send the Update (Using PATCH instead of POST)
    try {
      // 👇 THIS IS THE FIX: We use .patch() to standard URL, not .post() to custom URL
      const response = await client.patch(`/products/${product.id}/`, {
        quantity: newQty
      });

      // Update UI with server response
      setProduct(response.data);
      Alert.alert("Success", "Stock updated!");

    } catch (error) {
      console.log("Update Error:", error);

      // Improved Error Message
      let errorMsg = "Failed to update stock";
      if (error.response) {
         if (error.response.status === 404) {
             errorMsg = "Product not found on server.";
         } else {
             errorMsg = `Server Error: ${error.response.status}`;
         }
      } else if (error.request) {
         errorMsg = "Network Error. Check your connection.";
      }

      Alert.alert("Update Failed", errorMsg);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.imagePlaceholder}><Text style={{fontSize: 50}}>📦</Text></View>
      <View style={styles.content}>
        <View style={styles.headerRow}>
          <Text style={styles.title}>{product.name}</Text>
          <StatusBadge stock={product.quantity} minStock={product.min_stock_level} />
        </View>
        <Text style={styles.sku}>SKU: {product.sku}</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Quantity</Text>
          <Text style={styles.value}>{product.quantity}</Text>
          <Text style={styles.label}>Location</Text>
          <Text style={styles.value}>{product.warehouse_details?.location || "Unknown"}</Text>
        </View>

        <Text style={styles.sectionTitle}>Adjust Stock</Text>
        <View style={styles.stepper}>
            <TouchableOpacity style={[styles.stepBtn, {backgroundColor: '#EF4444'}]} onPress={() => updateStock('remove')}>
              <Text style={styles.stepText}>- Remove</Text>
            </TouchableOpacity>

            <TextInput
              style={styles.input}
              value={adjustAmount}
              onChangeText={setAdjustAmount}
              keyboardType="numeric"
            />

            <TouchableOpacity style={[styles.stepBtn, {backgroundColor: '#10B981'}]} onPress={() => updateStock('add')}>
              <Text style={styles.stepText}>+ Add</Text>
            </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  imagePlaceholder: { height: 200, backgroundColor: '#2563EB', justifyContent: 'center', alignItems: 'center' },
  content: { padding: 20, marginTop: -20, borderTopLeftRadius: 20, borderTopRightRadius: 20, backgroundColor: '#F3F4F6' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold' },
  sku: { color: '#666', marginBottom: 20 },
  card: { backgroundColor: '#fff', padding: 20, borderRadius: 12, marginBottom: 20 },
  label: { color: '#666', fontSize: 12 },
  value: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  stepper: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  stepBtn: { padding: 15, borderRadius: 8, minWidth: 100, alignItems: 'center' },
  stepText: { color: '#fff', fontWeight: 'bold' },
  input: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', minWidth: 50, backgroundColor: 'white', padding: 10, borderRadius: 8 },
});

export default ProductDetailsScreen;