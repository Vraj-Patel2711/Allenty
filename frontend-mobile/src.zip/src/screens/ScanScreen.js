import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import client from '../api/client';

const ScanScreen = ({ navigation }) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => setScanned(false));
    return unsubscribe;
  }, [navigation]);

  if (!permission) return <View />;
  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text style={{ textAlign: 'center' }}>Need camera permission</Text>
        <TouchableOpacity onPress={requestPermission} style={styles.permBtn}><Text>Grant</Text></TouchableOpacity>
      </View>
    );
  }

 const handleBarCodeScanned = async ({ data }) => {
     if (scanned) return;
     setScanned(true);

     try {
       // 1. Ask Server for matches
       const response = await client.get(`/products/?search=${data}`);

       // 2. 🛡️ STRICT CHECK: Ensure exact SKU match
       // (The server might return "123-A" when searching "123". We reject that here.)
       const exactMatch = response.data.find(p => p.sku === data);

       if (exactMatch) {
         // ✅ EXACT MATCH -> Go to Details
         navigation.navigate('ProductDetails', { product: exactMatch });
       } else {
         // ❌ NO EXACT MATCH -> Ask to Add
         Alert.alert(
           "New Product Found",
           `SKU ${data} is not in inventory. Do you want to add it?`,
           [
             { text: "Cancel", onPress: () => setScanned(false), style: "cancel" },
             {
               text: "Add to Inventory",
               onPress: () => navigation.navigate('AddProduct', { sku: data })
             }
           ]
         );
       }
     } catch (error) {
       console.log(error);
       Alert.alert("Error", "Connection failed", [
         { text: "Retry", onPress: () => setScanned(false) }
       ]);
     }
   };

  return (
    <View style={styles.container}>
      <CameraView
        style={styles.camera}
        facing="back"
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        barcodeScannerSettings={{ barcodeTypes: ["qr", "ean13", "ean8", "upc_a", "upc_e", "code128", "code39", "pdf417"] }}
      >
        <View style={styles.overlay}>
           <Text style={styles.scanText}>Scan Product Barcode</Text>
           <TouchableOpacity onPress={() => navigation.goBack()} style={styles.cancelBtn}><Text style={{color: 'white'}}>Cancel</Text></TouchableOpacity>
        </View>
      </CameraView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  camera: { flex: 1 },
  permBtn: { marginTop: 20, padding: 10, backgroundColor: '#ddd', alignSelf: 'center' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'space-between', padding: 50 },
  scanText: { color: 'white', fontSize: 24, textAlign: 'center', marginTop: 50 },
  cancelBtn: { padding: 15, backgroundColor: 'red', alignItems: 'center', borderRadius: 10 },
});

export default ScanScreen;
