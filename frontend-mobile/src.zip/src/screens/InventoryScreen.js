import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import axios from 'axios';

const API_URL = 'http://192.168.1.70:8000/api';

// Renamed to force Fast Refresh to reset the hook cache
export default function AppInventoryScreen() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const token = await AsyncStorage.getItem('accessToken');
      const res = await axios.get(`${API_URL}/products/`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const updateStock = async (id, currentQty, action) => {
    const newQty = action === 'add' ? currentQty + 1 : currentQty - 1;
    if (newQty < 0) return;

    setProducts(prev => prev.map(p => p.id === id ? { ...p, quantity: newQty } : p));

    try {
      const token = await AsyncStorage.getItem('accessToken');
      await axios.patch(`${API_URL}/products/${id}/`, { quantity: newQty }, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (err) {
      Alert.alert("Error", "Could not update stock");
      fetchProducts();
    }
  };

  const deleteProduct = async (id) => {
    Alert.alert("Delete Item", "Are you sure?", [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const token = await AsyncStorage.getItem('accessToken');
              await axios.delete(`${API_URL}/products/${id}/`, {
                headers: { Authorization: `Bearer ${token}` }
              });
              setProducts(prev => prev.filter(p => p.id !== id));
            } catch (err) {
              Alert.alert("Error", "Could not delete item");
            }
          }
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View>
          <Text style={styles.productName}>{item.name}</Text>
          <Text style={styles.sku}>{item.sku}</Text>
        </View>
        <TouchableOpacity onPress={() => deleteProduct(item.id)} style={styles.deleteBtn}>
           <Feather name="trash-2" size={20} color="#EF4444" />
        </TouchableOpacity>
      </View>

      <View style={styles.cardBody}>
        <View style={styles.locationBadge}>
           <Feather name="map-pin" size={12} color="#6B7280" />
           <Text style={styles.locationText}>{item.warehouse_details?.location || 'Main'}</Text>
        </View>

        <View style={styles.controls}>
          <TouchableOpacity onPress={() => updateStock(item.id, item.quantity, 'remove')} style={[styles.controlBtn, styles.removeBtn]}>
            <Feather name="minus" size={18} color="#EF4444" />
          </TouchableOpacity>

          <View style={[styles.qtyBadge, item.quantity <= item.min_stock_level ? styles.lowStock : styles.goodStock]}>
            <Text style={[styles.qtyText, item.quantity <= item.min_stock_level ? styles.lowStockText : styles.goodStockText]}>
              {item.quantity}
            </Text>
          </View>

          <TouchableOpacity onPress={() => updateStock(item.id, item.quantity, 'add')} style={[styles.controlBtn, styles.addBtn]}>
            <Feather name="plus" size={18} color="#10B981" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Inventory</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#2563EB" style={{marginTop: 50}} />
      ) : (
        <FlatList
          data={products}
          renderItem={renderItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB', padding: 20 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#111827', marginTop: 40, marginBottom: 20 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 15, marginBottom: 15, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 5, elevation: 2 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 15 },
  productName: { fontSize: 16, fontWeight: 'bold', color: '#111827' },
  sku: { fontSize: 12, color: '#9CA3AF', marginTop: 2 },
  deleteBtn: { padding: 5 },
  cardBody: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  locationBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F3F4F6', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  locationText: { fontSize: 12, color: '#6B7280', marginLeft: 4 },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  controlBtn: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  removeBtn: { backgroundColor: '#FEF2F2' },
  addBtn: { backgroundColor: '#ECFDF5' },
  qtyBadge: { minWidth: 40, alignItems: 'center', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 20, borderWidth: 1 },
  goodStock: { backgroundColor: '#ECFDF5', borderColor: '#D1FAE5' },
  lowStock: { backgroundColor: '#FEF2F2', borderColor: '#FEE2E2' },
  qtyText: { fontWeight: 'bold', fontSize: 14 },
  goodStockText: { color: '#047857' },
  lowStockText: { color: '#B91C1C' }
});