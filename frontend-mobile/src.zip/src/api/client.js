import axios from 'axios';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 1. DYNAMIC URL SELECTION
// Default to localhost for Web to avoid CORS/Firewall issues
let API_URL = 'http://localhost:8000/api'; 

// If on Mobile (Android/iOS), use your computer's Wi-Fi IP
if (Platform.OS !== 'web') {
  API_URL = 'https://ventilable-leontine-unfurbelowed.ngrok-free.dev/api'; 
}

const client = axios.create({
  baseURL: API_URL,
  headers: {
      'ngrok-skip-browser-warning': 'true',
      'Content-Type': 'application/json'
      }
});

// 2. TOKEN INTERCEPTOR (Keeps your existing login logic)
client.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default client;
