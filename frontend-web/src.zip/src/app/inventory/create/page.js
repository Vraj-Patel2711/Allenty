'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

export default function CreateProduct() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    quantity: 0,
    location: '',
    description: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('accessToken');
      await axios.post('http://localhost:8000/api/products/', formData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      // Success! Go back to the list
      router.push('/inventory');
    } catch (err) {
      alert('Failed to create product. Check console for details.');
      console.error(err);
    }
  };

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Add New Product</h1>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Product Name</label>
          <input 
            type="text" 
            required
            className="w-full border p-2 rounded mt-1"
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">SKU (Unique ID)</label>
            <input 
              type="text" 
              required
              className="w-full border p-2 rounded mt-1"
              onChange={(e) => setFormData({...formData, sku: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Quantity</label>
            <input 
              type="number" 
              required
              className="w-full border p-2 rounded mt-1"
              onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value)})}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Warehouse Location</label>
          <input 
            type="text" 
            className="w-full border p-2 rounded mt-1"
            onChange={(e) => setFormData({...formData, location: e.target.value})}
          />
        </div>

        <button type="submit" className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700">
          Save Product
        </button>
      </form>
    </div>
  );
}
